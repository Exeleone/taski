﻿using System;

namespace ConsoleAppTask5
{
    class Program
    {
        static void Main(string[] args)
        {
            AppleGarden appleGarden = new AppleGarden("Сады придонья", 100, 1000);
            appleGarden.Sow();
            Console.WriteLine(appleGarden.State);
            appleGarden.Collect();
            Console.WriteLine(appleGarden.State);

        }
    }
}
