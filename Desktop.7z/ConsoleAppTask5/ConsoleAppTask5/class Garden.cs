﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppTask5
{
    abstract class Garden : IPlot
    {
        int amount_trees;
        public Garden(int amount_trees)
        {
            this.amount_trees = amount_trees;
        }
        public string State { get; set; }

        public void Collect()
        {
            State = "Урожай собран";
        }

        public void Sow()
        {
            State = "Урожай посажен";
        }
    }
}
