﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppTask5
{
    class AppleGarden: Garden
    {
        string name;
        int squere;

        public AppleGarden(string name, int squere, int amount_trees) : base(amount_trees)
        {
            this.name = name;
            this.squere = squere;
        }

        public int get_squere()
        {
            return squere;
        }

        public void set_squere(int squere)
        {
            this.squere = squere;
        }

        public string get_name()
        {
            return name;
        }

        public void set_name(string name)
        {
            this.name = name;
        }
    }
}
