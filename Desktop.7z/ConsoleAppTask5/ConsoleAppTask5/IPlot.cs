﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppTask5
{
    interface IPlot
    {
        string State
        {
            get;
            set;
        }

        void Sow();

        void Collect();
    }
}
