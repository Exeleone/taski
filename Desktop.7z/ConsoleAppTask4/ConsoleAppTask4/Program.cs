﻿using System;

namespace ConsoleAppTask4
{
    class Program
    {
        static void Main(string[] args)
        {
            Institution_of_higher_education institution_Of_Higher_Education = 
                new Institution_of_higher_education("VSU", 120, 20);
            Console.WriteLine(institution_Of_Higher_Education.get_Q());
            Work_in_the_specialty work_In_The_Specialty = new Work_in_the_specialty("VSU", 120, 20, 50);
            Console.WriteLine(work_In_The_Specialty.get_Q());

        }
    }
}
