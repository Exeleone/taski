﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppTask4
{
    public class Institution_of_higher_education
    {
        string name;
        int amount_students_enrolled_in_the_1st_year;
        int amount_of_graduates;
        double Q;

        public Institution_of_higher_education(string name, int amount_students_enrolled_in_the_1st_year, int amount_of_graduates)
        {
            this.name = name;
            this.amount_students_enrolled_in_the_1st_year = amount_students_enrolled_in_the_1st_year;
            this.amount_of_graduates = amount_of_graduates;
            this.Q = set_Q(amount_students_enrolled_in_the_1st_year, amount_of_graduates);

        }

        public virtual double set_Q(int amount_students_enrolled_in_the_1st_year, int amount_of_graduates)
        {
            return (double)amount_of_graduates / amount_students_enrolled_in_the_1st_year;
        }

        public double get_Q()
        {
            return (double)Q;
        }
    }
}
