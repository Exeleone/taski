﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppTask4
{
    public class Work_in_the_specialty: Institution_of_higher_education
    {
        int P;
        double Qp;

        public Work_in_the_specialty(string name, int amount_students_enrolled_in_the_1st_year, int amount_of_graduates, int P) : base(name, amount_students_enrolled_in_the_1st_year, amount_of_graduates)
        {
            this.P = P;
            this.Qp = set_Q(P);

        }
        public double set_Q(int P)
        {
            return P * (double)base.get_Q();
        }

        public double get_Q()
        {
            return Qp;
        }
    }
}
